# setup.py
from setuptools import setup, find_packages
import os

# Dynamically get the current directory
current_dir = os.path.dirname(os.path.realpath(__file__))

# Read the README file
with open(os.path.join(current_dir, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='twofish_package',
    version='0.3.0',
    description='Twofish encryption algorithm',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Your Name',
    author_email='your.email@example.com',
    packages=find_packages(),
    package_data={'twofish': ['_twofish.cp39-win_amd64.pyd', 'twofish.py']},
    include_package_data=True,
)
